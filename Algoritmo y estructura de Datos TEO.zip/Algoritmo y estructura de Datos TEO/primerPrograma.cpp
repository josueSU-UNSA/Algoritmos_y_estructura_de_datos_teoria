#include<iostream>
#include "conio.h"
using namespace std;
template <typename T>
class Nodo{
    private:
        T value;
        Nodo<T>* next;
    public:
        Nodo(T value){
            this->value=value;
            this->next=nullptr;
        }
        Nodo(){
            
            this->next=nullptr;
        }
        T getValue() const{
            return this->value;
        }
        Nodo<T>* getNext()const{
            return this->next;
        }
        void setValue(T value){
            this->value=value;
        }
        void setNext(Nodo<T>* next){
            this->next=next;
        }
};
template <typename G>
class SimpleLinkedList{
    private:
        Nodo<G>*head;
        int longitud;
    public:
        SimpleLinkedList(){
            this->head=nullptr;
            this->longitud=0;
        }
        SimpleLinkedList(G value){
            this->longitud=1;
            this->head=new Nodo<G>(value);
        }
        Nodo<G>*getHead(){
            return this->head;
        }
        void insertPos(int pos,G value){
            Nodo<G>*auxLeft=nullptr;
            Nodo<G>*auxRight=this->head;
            Nodo<G>*nodoInsert=new Nodo<G>(value);
            int iterador=0;
            if(pos>=0 and pos<this->longitud){
                if(pos==0){
                    insertBegin(value);
                    this->longitud++;
                }
                else if(pos==this->longitud-1){
                    insertEnd(value);
                    this->longitud++;
                }
                else{
                    while (iterador<pos)
                    {
                        auxLeft=auxRight;
                        auxRight=auxRight->getNext();
                        iterador++;
                    }
                    auxLeft->setNext(nodoInsert);
                    nodoInsert->setNext(auxRight);
                    this->longitud++;
                }
            }
            else{
                cout<<"El indice ingresado esta fuera de rango"<<endl;
            }
            

            

        }

       
        
        void insertEnd(G value){
            Nodo<G>*aux=this->head;
            Nodo<G>*nodoInsert=new Nodo<G>(value);
            //Nodo<G>nuevo
            if(head==nullptr){
                this->head=nodoInsert;
            }
            else{
                while (aux->getNext()!=nullptr){
                    //aux=aux->getNext;
                    aux=aux->getNext();
                }
                aux->setNext(nodoInsert);
                
            }
            //delete nodoInsert;
            

            
            this->longitud++;
        }

        void insertBegin(G value){
            Nodo<G>*aux=this->head;
            Nodo<G>*nodoInsert=new Nodo<G>(value);
            //Nodo<G>nuevo
            this->head=nodoInsert;
            nodoInsert->setNext(aux);
           
            //delete nodoInsert;
            

            
            this->longitud++;
        }
        int getLongitud(){
            return this->longitud;
        }

        void print(){
            Nodo<G>*aux=this->head;
            //Nodo<G>nuevo
            
            while (aux!=nullptr){
                
                //aux=aux->getNext;
                cout<<aux->getValue()<<" ";
                aux=aux->getNext();
                
            }
            
            
        }


        //PRINT RECURSIVO
        void printRec(Nodo<G>*ptr){
            if(ptr==nullptr){
                return;
            }
            else{
                cout<<ptr->getValue()<<" ";
                printRec(ptr->getNext());
            }
        }   

        //ADD RECURSIVO(AL FINAL)
        void AddRec(G value,Nodo<G>*ptr){
            if(this->head==nullptr){
                this->head=new Nodo<G>(value);
                this->longitud++;
                return;
            }
            else if(ptr->getNext()==nullptr){
                ptr->setNext(new Nodo<G>(value));
                this->longitud++;
                return;
            }
            else{
                AddRec(value,ptr->getNext());
            }
        }
        void AddRecursivoProfe(G value,Nodo<G>*&ptr){
            if(ptr==nullptr){
                ptr=new Nodo<G>(value);
                this->longitud++;
                return;
            }
            else{
                Add(value,ptr->getNext());
            }
        }
        
        //FIND RECURSIVO
        bool findRecursivo(Nodo<G>*ptr,G value){
            if(ptr==nullptr){
                return false;
            }
            if(ptr->getValue()==value){
                return true;
            }
            else{
                return findRecursivo(ptr->getNext(),value);
            }
        }
        
        //DELETE FRONT 
        void deleteFront(){//elimina el primer elemento
            if(this->head==nullptr){return;}
            Nodo<G>*aux=this->head->getNext();
            delete head;
            head=aux;
            this->longitud--;
            
        }
        
        //DELETE BACK 
        
        void deleteBack(){//elimina el ultimo elemento
            Nodo<G>*auxL,*auxR;
            auxL=nullptr;
            auxR=this->head;
            if(this->head==nullptr){
                return;
            }
            else{
                while(auxR->getNext()!=nullptr){
                    auxL=auxR;
                    auxR=auxR->getNext();
                }
                delete auxR;
                auxL->setNext(nullptr);
                this->longitud--;
            }

        }
        
       /*
       void deleteBack() {
        if (!this->head)
            return;
        if (!this->head->getNext())
            delete this->head;
        else {
            Nodo<G>* tmp = this->head;
            for(; tmp->getNext()->getNext(); tmp = tmp->getNext());
            tmp->setNext(nullptr);
            delete tmp->getNext();
        }
    }
    */
        //L1 UNION(L2)
        void united(SimpleLinkedList<G>lista2){
            Nodo<G>*tmp= lista2.getHead();
            while(tmp!=nullptr){
                if(find(tmp->getValue)!=false){
                    AddRec(tmp->getValue(),this->head);
                    tmp=tmp->getNext();
                }
                else{
                    tmp=tmp->getNext();
                }
                
            }
        }
        
        //L2 INTERSECCION L1

};
int main(){
cout<<"Hello world"<<endl;
    
    Nodo<int> prueba;
    
    SimpleLinkedList<int> lista;
    SimpleLinkedList<int> lista2;
    lista.insertEnd(3);
    lista.insertEnd(13);
    lista.insertEnd(39);
    lista2.insertEnd(1000);
    lista2.insertEnd(2000);
    lista2.insertEnd(3000);
    lista.insertBegin(4);
    lista.insertBegin(17);
    
    lista.insertBegin(100);
        
    cout<<endl;
    lista.insertPos(3,15);
    lista.AddRec(7,lista.getHead());

    cout<<endl;
    cout<<lista.getLongitud();
    cout<<endl;
    lista.printRec(lista.getHead());
    
    //lista.print();
    lista.deleteFront();
    cout<<endl;
    cout<<lista.getLongitud();
    cout<<endl;
    lista.printRec(lista.getHead());
    cout<<endl;

    lista.AddRec(13,lista.getHead());
    cout<<lista.getLongitud();
    cout<<endl;
    lista.printRec(lista.getHead());
    
    
    cout<<endl;
    lista.deleteBack();
    cout<<lista.getLongitud();
    cout<<endl;
    lista.printRec(lista.getHead());
    lista.united(lista2);
    lista.print();
    //lista.print();    
    getch();
    return 0;
}
/*
void deleteBack(){
    
    Nodo<G>*auxNext=this->head;
    Nodo<G>*aux=nullptr;
    while(auxNext->m_pSig!=nullptr){
        aux=auxNext;
        auxNext=auxNext->m_pSig;    
    }

    delete auxNext;
    aux->setNext(nullptr);

    
}
//DELETE BACK
void delete_back() {
        if (!m_pHead)
            return;
        if (!m_pHead->m_pSig)
            delete m_pHead;
        else {
            Nodo<T>* tmp = m_pHead;
            for(; tmp->m_pSig->m_pSig; tmp = tmp->m_pSig);
            tmp->m_pSig = 0;
            delete tmp->m_pSig;
        }
    }
*/



