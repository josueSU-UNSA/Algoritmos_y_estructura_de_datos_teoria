#include "Node.h"
using namespace std;
template<typename T>
class BinaryTree{
    private:
        Node<T>*m_pRoot;
    public:
        BinaryTree(){
            this->m_pRoot=0;
        }
        void Add(T value){
            if(!this->m_pRoot)this->m_pRoot=new Node<T>(value);
            
        }
};