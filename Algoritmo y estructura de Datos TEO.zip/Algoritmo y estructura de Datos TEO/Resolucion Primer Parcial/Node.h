template<typename T>
class Node{
    public:
        T value;
        
        Node<T>*m_pSig[3];
    public:
        Node(T value){
            this->value=value;
            this->m_pSig[0]=0;
            this->m_pSig[1]=0;
            this->m_pSig[2]=0;
        }
};