#include<iostream>
#include "CImg.h"
#include<map>


using namespace std;
using namespace cimg_library;

typedef std::map< int, std::map<int , int > >  TMatriz;

CImg<char>   Binarizar(CImg<float> & img, int umbral)
{
    CImg<char> R(img.width(),img.height(),1);
    for(int i=0;i<img.width();i++)
       for(int j=0;j<img.height();j++)
       {
            float s = (img(i,j,0) + img(i,j,1) + img(i,j,2))/3;
            if(s > umbral)
                R(i,j) = 0;
            else
                R(i,j) = 255; 
           
       }
       return R;
}

TMatriz Comprimir(CImg<char> & img)
{
      TMatriz R;
       for(int i=0;i<img.width();i++)
            for(int j=0;j<img.height();j++)
            {
                   if(img!=0) R[i][j] = 255;           
            }
        return R;
}

CImg<char> Descomprimir(TMatriz & R)
{
    CImg<char> img; 
    // Write the code heare
    return img;
}

int main()
{
     TMatriz Img;
     CImg<float>  A("foto1.jpeg");
     A.display();
     CImg<char> R = Binarizar(A,80);
     R.display();
     Img = Comprimir(R);
   
    
    return 1;
}